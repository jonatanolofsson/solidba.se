var triggerBug = {_default: "*/*"};
var essentialFunctionality = true;
